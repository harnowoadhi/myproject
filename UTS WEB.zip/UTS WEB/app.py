from flask import Flask, redirect,render_template, jsonify
from flask import url_for
from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

class Base(DeclarativeBase):
  pass

db = SQLAlchemy(model_class=Base)

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql://root:@127.0.0.1/flask"
db.init_app(app)

db.Model
db.session

class User(db.Model):
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String)

with app.app_context():
    db.create_all()

@app.route("/", methods=["GET"])
def user_list():
    users = User.query.order_by(User.email).all()
    user_list = [{'id': user.id, 'email': user.email, 'name': user.name} for user in users]
    return jsonify(user_list)

@app.route("/create", methods=["POST"])
def user_create():
    data = request.get_json()
    email = data.get('email')
    name = data.get('name')

    existing_user = User.query.filter_by(email=email).first()

    if existing_user:
        return jsonify({'message': 'Email sudah ada'}), 400

    user = User(email=email, name=name)

    db.session.add(user)
    db.session.commit()

    return jsonify({'message': 'User berhasil dibuat'})

@app.route("/edit/<int:user_id>", methods=["PUT"])
def user_edit(user_id):
    user = User.query.get(user_id)

    if user is None:
        return jsonify({'message': 'User tidak ditemukan'}), 404

    data = request.get_json()
    email = data.get('email', user.email)
    name = data.get('name', user.name)

    existing_user = User.query.filter(User.id != user_id, User.email == email).first()

    if existing_user:
        return jsonify({'message': 'Email sudah digunakan oleh pengguna lain'}), 400

    user.email = email
    user.name = name
    db.session.commit()

    return jsonify({'message': 'User berhasil diperbarui'})

@app.route("/delete/<int:user_id>", methods=["DELETE"])
def user_delete(user_id):
    user = User.query.get(user_id)

    if user is None:
        return jsonify({'message': 'User tidak ditemukan'}), 404

    db.session.delete(user)
    db.session.commit()

    return jsonify({'message': 'User berhasil dihapus'})

@app.route('/upload', methods=['GET','POST'])
def upload_file():
    if request.method =='POST':
        f = request.files['image']
        f.save('image.jpg')
    return {
            "message" : "success"
    },200


if __name__ == '__main__':
    app.run(debug=True)